<html>
<head>
	<title>Tutorial Laravel - www.malasngoding.com</title>
</head>
<body>
 
	<h3>www.malasngoding.com</h3>
	<p>Seri Tutorial Laravel Lengkap Dari Dasar</p>
	<p>Ini adalah view blog. ada di route blog.</p>
 
</body>
</html><?php /**PATH R:\software\xampp\htdocs\laravel_1\resources\views/blog.blade.php ENDPATH**/ ?>